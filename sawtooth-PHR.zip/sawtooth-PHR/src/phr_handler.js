const { TransactionHandler } = require('sawtooth-sdk/processor/handler');
const {InternalError,InvalidTransaction}=require('sawtooth-sdk').exceptions;
const { hash } = require('./lib/helper');
const cbor= require('cbor');
const crypto = require('crypto');
const FAMILY_NAME = "phr-family", VERSION = ["1.0"], NAMESPACE = ["phr", "phrfam", hash(FAMILY_NAME)]
const MongoClient = require('mongodb').MongoClient;
const assert = require('assert');

const url = 'mongodb://localhost:27017';
const dbName= 'phr';
const client = new MongoCLient(url);


const decodeData = (payload) =>{
	return new Promise((resolve,reject) =>{
	let decodedPayload=cbor.decode(payload)
	console.log(decodedPayload)
        //let result = JSON.parse(decodedPayload);
	//console.log(result)
	let reason = new InvalidTransaction('Invalid payload')
	//decodedPayload ? resolve(decodedPayload):reject(reason);
	
	let payload1 = decodedPayload.toString().split(',')
	if(payload1){
		resolve({
			pid: payload1[0],
			action: payload1[1],
			category: payload1[2],
			age: payload1[3]
		})
	}
	else {
		let reason = new InvalidTransaction('Invalid payload serialization')
		reject(reason)
	}


	})
}

class PhrHandler extends TransactionHandler {
    constructor() {
       super(FAMILY_NAME, VERSION, NAMESPACE);
    }
    apply(transactionProcessRequest, context) {
        return decodeData(transactionProcessRequest.payload)
            .then((update)=> {
		console.log(update)
		if (!update.pid){
                    throw new InvalidTransaction("Payload has no ID ");
                }
                if (!update.action){
                    throw new InvalidTransaction("payload doesn't contain the action");
                }
                if (!update.category){
                    throw new InvalidTransaction("Payload has no category");
                }
                let action = (update.action).toString();
		console.log(action)
                let address = NAMESPACE[2] + hash(update.pid).substring(0,64);
                switch(action){
                    case "upload":
                        let entries = {
                            [address] : cbor.encode(update.age)
                        }
                        context.setState(entries);
			client.connect(url, function (err,client){
				assert.equal(null,err);
				console.log("Connected correctly to server");
				const db=client.db(dbName);
				db.collection('uploads').insertOne({patientId:update.pid},{category:update.category}, function(err,r){
				assert.equal(null,err);
				assert.equal(1,r.insertedCount);
				client.close();
				});
			});
			break;

                    case "read":
                        /*context.getState([address])
                            .then((possibleAddressValues)=>{
                                let stateValue = possibleAddressValues[address];
                                if(stateValue && stateValue.length){
                                    let value = cbor.decodeFirstSync(stateValue);
					 console.log(value[id])
                                    if(value[id]){
                                        console.log(value.age)
                                    }
                                    else{
                                        throw new InvalidTransaction("Invalid Transaction")
                                    }
                                }
                            }) 
*/
			 let entries = {
                            [address] : cbor.encode(update.action)
                        }
                        context.setState(entries);
			client.connect(url, function (err,client){
				assert.equal(null,err);
				console.log("Connected correctly to server");
				const db=client.db(dbName);
				const col=db.collection('uploads')
				console.log(col.find())
				client.close();
			});
			
			break;                      

                    default:
			//console.log(update.action)
                    throw new InvalidTransaction("The action is not supported/invalid");
                }
            })
            .catch((err) => {
                throw new InternalError(err);
            })
    }
}
 
module.exports = PhrHandler

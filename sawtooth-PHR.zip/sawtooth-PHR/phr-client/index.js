const { EnclaveFactory } = require('./enclave')
const { SawtoothClientFactory } = require('./sawtooth-client')
const argv = require('yargs')
  .usage('Usage: --pid [integer] --action [upload, read] --category [lifestyle, history, personal] --age [integer]')
  .choices('action', ['upload', 'read'])
  .number(['pid','age'])
  .string(['action', 'category'])
  .describe('name', 'unique identifier for the entry')
  .describe('verb', 'action to take on the entry')
  .describe('value', 'value to pass to the entry')
  .example('node index.js --name foo --verb set --value 42', 'If `foo` is undefined, create it and set its value to 42')
  .example('node index.js --name foo --verb inc --value 13', 'If `foo` is defined, increment it by 13')
  .example('node index.js --name foo --verb dec --value 7', 'If `foo` is defined, decrement it by 7 (but not below 0)')
  .wrap(null)
  .demandOption(['pid', 'action', 'category', 'age'])
  .help('h')
  .alias('h', 'help')
  .argv

const env = require('./env')
const input = require('./input')

const enclave = EnclaveFactory(Buffer.from(env.privateKey, 'hex'))

const phrClient = SawtoothClientFactory({
  enclave: enclave,
  restApiUrl: env.restApiUrl
})

const phrTransactor = phrClient.newTransactor({
  familyName: env.familyName,
  familyVersion: env.familyVersion
})

const newPayload = {
  pid: argv.pid,
  action: argv.action,
  category: argv.category,
  age:argv.age
}

var Payload=""
Payload=argv.pid+","+argv.action+","+argv.category+","+argv.age
//const Payload ="101,read,lifestyle,17"
if (input.payloadIsValid(Payload)) {
  input.submitPayload (Payload, phrTransactor)
} else {
  console.log(`Oops! Your payload failed validation and was not submitted.`)
}

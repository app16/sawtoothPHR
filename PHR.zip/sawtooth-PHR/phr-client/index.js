const { EnclaveFactory } = require('./enclave')
const { SawtoothClientFactory } = require('./sawtooth-client')
const cbor= require('cbor');
const argv = require('yargs')
  .usage('Usage: --pid [integer] --action [upload] --category [lifestyle, history, personal] --age [integer] ')
  .usage('Usage: --docid [integer] --action [read]' )
  .usage('Usage: --pid [integer] --action [request] --category [lifestyle, history, personal] --docid [integer]')
  //.choices('action', ['upload','read','request'])
  .number(['pid','age' ,'docid'])
  .string(['action', 'category'])
//  .describe('name', 'unique identifier for the entry')
  //.example('node index.js --name foo --verb set --value 42', 'If `foo` is undefined, create it and set its value to 42')
  .wrap(null)
  //.demandOption(['pid', 'action', 'category', 'age', 'docid'])
  .help('h')
  .alias('h', 'help')
  .argv
const http = require('http');
const env = require('./env')
//const input = require('./input')
const {input,fetch} = require('./input')

const enclave = EnclaveFactory(Buffer.from(env.privateKey, 'hex'))

const phrClient = SawtoothClientFactory({
  enclave: enclave,
  restApiUrl: env.restApiUrl
})

const phrTransactor = phrClient.newTransactor({
  familyName: env.familyName,
  familyVersion: env.familyVersion
})
var Payload=""
console.log(argv.action)
if (argv.action === "upload") { 
/*var newPayload = {
  pid: argv.pid,
  action: argv.action,
  category: argv.category,
  age:argv.age
}*/
console.log("in upload")
console.log(argv.action)
Payload=""
Payload=argv.pid+","+argv.action+","+argv.category+","+argv.age
}
else if (argv.action === "read") {
/*var newPayload = {
	pid: argv.pid,
	action: argv.action,
	category: argv.category
	}*/
console.log("in read")
console.log(argv.action)
console.log(argv.docid)
Payload=""
Payload = argv.docid+","+argv.action
var options = {
	host: 'localhost',
	port: 8008,
	path:'/transactions'
}
	http.get(options,function(resp){
		console.log(resp.statusCode)
		var fulldata ='';
		resp.on('data',function(chunk) {
		fulldata+=chunk
		//svar fulldata = JSON.parse(fulldata)
		//fulldata= fulldata.toString()
		});

		resp.on('end',function(){
		var stringdata = JSON.parse(fulldata)
		
		for (var i= 0 ; stringdata.data[i]!= null; i++){
		console.log(i)
		console.log(stringdata.data[i].payload);
		/*let outputdata = stringdata.data[0].payload
		console.log(outputdata);*/
}
	
	});
	}).on("error",function (err){
		console.log("Error: " +err.message);
	});

} 
else if (argv.action === "request") {
/*var newPayload = {
	pid: argv.pid,
	action: argv.action,
	category: argv.category
	docid: argv.docid
	}*/
console.log("in request")
console.log(argv.action)
Payload=""
Payload=argv.pid+","+argv.action+","+argv.category+","+argv.docid
} 

//const Payload ="101,read,lifestyle,17"
if (input.payloadIsValid(Payload)) {
  input.submitPayload (Payload, phrTransactor)
} else {
  console.log(`Oops! Your payload failed validation and was not submitted.`)
}
/*
if (argv.action === "read") {
 fetch.fetchPayload(Payload, phrTransactor)
}  else {
  console.log(`Oops! Read request failed.`)
}
*/

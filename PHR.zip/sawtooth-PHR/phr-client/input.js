
const input = {
  payloadIsValid: (payload) => {
  //  if (IsIdValid(payload.pid) && IsActionValid(payload.action) && IsCategoryValid(payload.category) && IsAgeValid(payload.age)) return true
  //  else return false
	return true
  },
  submitPayload: async (payload, transactor) => {
    try {
      // Format the Sawtooth transaction
      const txn = payload
      console.log(`Submitting transaction to Sawtooth REST API`)
      // Wait for the response from the validator receiving the transaction
      const txnRes = await transactor.post(txn)
      // Log only a few key items from the response, because it's a lot of info
      console.log({
        status: txnRes.status,
        statusText: txnRes.statusText
      })
      return txnRes
    } catch (err) {
      console.log('Error submitting transaction to Sawtooth REST API: ', err)
      console.log('Transaction: ', txn)
    }
  }
}
const fetch = {
  fetchPayload: async (payload, transactor) => {
    try {
      // Format the Sawtooth transaction
      const txn = payload
      console.log(`Sending fetch request to Sawtooth REST API`)
      // Wait for the response from the validator receiving the transaction
      const fetchRes = await transactor.getState()
      // Log only a few key items from the response, because it's a lot of info
      console.log({
        status: fetchRes.status,
        statusText: fetchRes.statusText
      })
      return fetchRes
    } catch (err) {
      console.log('Error submitting transaction to Sawtooth REST API: ', err)
      console.log('Transaction: ', txn)
    }
  }
}

const isInteger = (value) => {
  if (isNaN(value)) {
    return false
  }
  var x = parseFloat(value)
  return (x | 0) === x
}

const IsActionValid = (action) => {
  const trimmed = action.trim()
  if (trimmed === 'upload' || trimmed === 'read') return true
  else return false
}

const IsCategoryValid = (category) => {
  const trimmed = category.trim()
  if (trimmed === 'personal' || trimmed === 'lifestyle' || trimmed === 'history') return true
  else return false
}

const IsIdValid = (value) => {
  if ((isInteger(value)) && (value >= 0) && (value < Math.pow(2, 32) - 1)) return true
  else return false
}

const IsAgeValid = (value) => {
  if ((isInteger(value)) && (value >= 0) && (value < 110)) return true
  else return false
}

module.exports = { input,
//fetch
 }
